-- =============================================================================
-- UTU Pantallas — esquema inicial
-- Ejecutar en Supabase: SQL Editor → pegar y "Run" (o `supabase db push`).
-- =============================================================================

-- ---------------------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------------------
create type public.media_type as enum ('video', 'image', 'text');
create type public.post_status as enum ('pending', 'approved', 'rejected', 'played');

-- ---------------------------------------------------------------------------
-- Moderadores
-- Solo los usuarios listados acá pueden moderar y ver la pantalla.
-- Alta: insert into public.moderators (user_id) select id from auth.users where email = '...';
-- ---------------------------------------------------------------------------
create table public.moderators (
  user_id    uuid primary key references auth.users (id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.moderators enable row level security;

create or replace function public.is_moderator()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (select 1 from public.moderators where user_id = auth.uid());
$$;

grant execute on function public.is_moderator() to anon, authenticated;

create policy "moderators: leer la propia fila"
  on public.moderators for select to authenticated
  using (user_id = auth.uid());

-- ---------------------------------------------------------------------------
-- posts: contenido enviado por la comunidad
-- content_url guarda la RUTA del objeto dentro del bucket `community-media`
-- (ej. "video/2f1c...e9.webm"), nunca una URL arbitraria.
-- ---------------------------------------------------------------------------
create table public.posts (
  id          uuid primary key default gen_random_uuid(),
  type        public.media_type  not null,
  content_url text,
  message     text,
  duration    integer            not null default 5,
  status      public.post_status not null default 'pending',
  created_at  timestamptz        not null default now(),
  approved_at timestamptz,

  constraint posts_message_len check (message is null or char_length(message) between 1 and 280),
  constraint posts_content_shape check (
    case type
      when 'text'  then content_url is null and message is not null
      when 'image' then content_url ~ '^image/[0-9a-f-]{36}\.(jpg|jpeg|png|webp)$'
      when 'video' then content_url ~ '^video/[0-9a-f-]{36}\.(webm|mp4|mov)$'
    end
  )
);

create index posts_status_idx on public.posts (status, approved_at, created_at);

-- Fuerza los valores controlados por el servidor (duración, estado inicial, fechas)
create or replace function public.posts_before_insert()
returns trigger
language plpgsql
as $$
begin
  new.duration    := case new.type when 'text' then 10 else 5 end;
  new.created_at  := now();
  new.approved_at := null;
  if not public.is_moderator() then
    new.status := 'pending';
  end if;
  return new;
end;
$$;

create trigger posts_before_insert
  before insert on public.posts
  for each row execute function public.posts_before_insert();

-- Registra el momento de aprobación: la cola se reproduce en orden FIFO de aprobación
create or replace function public.posts_before_update()
returns trigger
language plpgsql
as $$
begin
  if new.status = 'approved' and old.status is distinct from 'approved' then
    new.approved_at := now();
  end if;
  return new;
end;
$$;

create trigger posts_before_update
  before update on public.posts
  for each row execute function public.posts_before_update();

alter table public.posts enable row level security;

-- Cualquiera (sin login) puede enviar contenido, siempre en estado pendiente
create policy "posts: público puede enviar pendientes"
  on public.posts for insert to anon, authenticated
  with check (status = 'pending');

create policy "posts: moderadores leen"
  on public.posts for select to authenticated
  using (public.is_moderator());

create policy "posts: moderadores actualizan"
  on public.posts for update to authenticated
  using (public.is_moderator())
  with check (public.is_moderator());

create policy "posts: moderadores borran"
  on public.posts for delete to authenticated
  using (public.is_moderator());

grant usage on type public.media_type, public.post_status to anon, authenticated;
grant insert on public.posts to anon, authenticated;
grant select, update, delete on public.posts to authenticated;

-- ---------------------------------------------------------------------------
-- promotions: playlist de propaganda
-- content_url guarda la RUTA del objeto dentro del bucket privado `promo-media`.
-- ---------------------------------------------------------------------------
create table public.promotions (
  id          uuid primary key default gen_random_uuid(),
  type        public.media_type not null,
  content_url text,
  message     text,
  duration    integer           not null default 5 check (duration between 3 and 120),
  is_active   boolean           not null default true,
  created_at  timestamptz       not null default now(),

  constraint promotions_content_shape check (
    case type
      when 'text' then message is not null and char_length(message) > 0
      else content_url is not null
    end
  )
);

alter table public.promotions enable row level security;

create policy "promotions: moderadores gestionan"
  on public.promotions for all to authenticated
  using (public.is_moderator())
  with check (public.is_moderator());

grant select, insert, update, delete on public.promotions to authenticated;

-- ---------------------------------------------------------------------------
-- Realtime
-- ---------------------------------------------------------------------------
alter publication supabase_realtime add table public.posts, public.promotions;

-- ---------------------------------------------------------------------------
-- Storage
-- ---------------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('community-media', 'community-media', true,  20971520,
     array['image/jpeg', 'image/png', 'image/webp', 'video/webm', 'video/mp4', 'video/quicktime']),
  ('promo-media',     'promo-media',     false, 104857600,
     array['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'video/webm', 'video/mp4'])
on conflict (id) do nothing;

-- community-media: lectura pública (bucket público), subida anónima, borrado solo moderadores
create policy "community-media: subida pública"
  on storage.objects for insert to anon, authenticated
  with check (
    bucket_id = 'community-media'
    and (storage.foldername(name))[1] in ('image', 'video')
  );

create policy "community-media: moderadores borran"
  on storage.objects for delete to authenticated
  using (bucket_id = 'community-media' and public.is_moderator());

-- promo-media: todo restringido a moderadores (la pantalla usa URLs firmadas)
create policy "promo-media: moderadores leen"
  on storage.objects for select to authenticated
  using (bucket_id = 'promo-media' and public.is_moderator());

create policy "promo-media: moderadores suben"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'promo-media' and public.is_moderator());

create policy "promo-media: moderadores actualizan"
  on storage.objects for update to authenticated
  using (bucket_id = 'promo-media' and public.is_moderator());

create policy "promo-media: moderadores borran"
  on storage.objects for delete to authenticated
  using (bucket_id = 'promo-media' and public.is_moderator());
