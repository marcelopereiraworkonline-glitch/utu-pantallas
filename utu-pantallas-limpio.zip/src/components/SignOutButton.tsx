"use client";

import { useRouter } from "next/navigation";
import { getSupabase } from "@/lib/supabase/client";

export function SignOutButton() {
  const router = useRouter();
  return (
    <button
      onClick={async () => {
        await getSupabase().auth.signOut();
        router.replace("/login");
        router.refresh();
      }}
      className="rounded-xl px-4 py-2 text-sm text-zinc-400 ring-1 ring-white/10 hover:bg-white/5 hover:text-white"
    >
      Cerrar sesión
    </button>
  );
}
