"use client";

import type { Slot } from "@/hooks/usePlaylist";

interface Props {
  slot: Slot;
  /** Se llama si el archivo no carga: se salta a la siguiente pieza */
  onError: () => void;
}

export function MediaStage({ slot, onError }: Props) {
  return (
    <div className="absolute inset-0 animate-[fade-in_400ms_ease-out]">
      {slot.type === "text" && <TextSlide message={slot.message ?? ""} source={slot.source} />}

      {slot.type === "image" && slot.url && (
        <>
          {/* Fondo desenfocado para rellenar fotos verticales en pantallas 16:9 */}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={slot.url} alt="" aria-hidden className="absolute inset-0 h-full w-full scale-110 object-cover opacity-40 blur-3xl" />
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={slot.url} alt={slot.message ?? ""} onError={onError} className="relative h-full w-full object-contain" />
        </>
      )}

      {slot.type === "video" && slot.url && (
        <>
          <video
            src={slot.url}
            autoPlay
            muted
            playsInline
            loop
            aria-hidden
            className="absolute inset-0 h-full w-full scale-110 object-cover opacity-40 blur-3xl"
          />
          <video
            src={slot.url}
            autoPlay
            playsInline
            // Los anuncios pueden durar más que su video; los de la comunidad duran 5 s exactos
            loop={slot.source === "promo"}
            onError={onError}
            className="relative h-full w-full object-contain"
          />
        </>
      )}

      {slot.type !== "text" && slot.message && (
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent px-16 pb-16 pt-32">
          <p className="max-w-5xl text-4xl font-semibold leading-tight text-white drop-shadow-lg">{slot.message}</p>
        </div>
      )}
    </div>
  );
}

function TextSlide({ message, source }: { message: string; source: Slot["source"] }) {
  // Tamaño de fuente adaptado a la longitud del mensaje (máx. 280 caracteres)
  const size = message.length < 60 ? "text-8xl" : message.length < 140 ? "text-7xl" : "text-5xl";
  const gradient =
    source === "community"
      ? "from-indigo-950 via-slate-950 to-fuchsia-950"
      : "from-sky-950 via-slate-950 to-emerald-950";

  return (
    <div className={`flex h-full w-full items-center justify-center bg-gradient-to-br ${gradient} p-24`}>
      <p className={`${size} max-w-6xl text-balance text-center font-bold leading-tight tracking-tight text-white`}>
        <span className="text-white/30">“</span>
        {message}
        <span className="text-white/30">”</span>
      </p>
    </div>
  );
}
