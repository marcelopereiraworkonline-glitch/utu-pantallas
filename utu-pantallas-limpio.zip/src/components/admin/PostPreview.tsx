import type { MediaType } from "@/lib/types";

interface Props {
  type: MediaType;
  url: string | null;
  message: string | null;
  className?: string;
}

export function PostPreview({ type, url, message, className = "" }: Props) {
  return (
    <div className={`relative overflow-hidden bg-black ${className}`}>
      {type === "text" && (
        <div className="flex h-full items-center justify-center bg-gradient-to-br from-indigo-950 to-fuchsia-950 p-4">
          <p className="line-clamp-6 text-center font-medium">{message}</p>
        </div>
      )}
      {type === "image" && url && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={url} alt="" className="h-full w-full object-contain" />
      )}
      {type === "video" && url && (
        <video src={url} autoPlay muted loop playsInline controls className="h-full w-full object-contain" />
      )}
      {type !== "text" && message && (
        <p className="absolute inset-x-0 bottom-0 bg-black/70 px-3 py-2 text-sm">{message}</p>
      )}
    </div>
  );
}
