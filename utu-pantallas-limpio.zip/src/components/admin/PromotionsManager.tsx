"use client";

import { useCallback, useState } from "react";
import { getSupabase } from "@/lib/supabase/client";
import { baseMime, buildObjectPath, resolvePromotions, type ResolvedPromotion } from "@/lib/media";
import { PROMO_BUCKET, type MediaType, type Promotion } from "@/lib/types";
import { useRealtimeTable } from "@/hooks/useRealtimeTable";
import { PostPreview } from "@/components/admin/PostPreview";

const DEFAULT_DURATION: Record<MediaType, number> = { video: 5, image: 5, text: 10 };

export function PromotionsManager() {
  const [promos, setPromos] = useState<ResolvedPromotion[]>([]);
  const [type, setType] = useState<MediaType>("image");
  const [file, setFile] = useState<File | null>(null);
  const [message, setMessage] = useState("");
  const [duration, setDuration] = useState(DEFAULT_DURATION.image);
  const [busy, setBusy] = useState(false);
  const [formKey, setFormKey] = useState(0);

  const load = useCallback(async () => {
    const { data, error } = await getSupabase().from("promotions").select("*").order("created_at", { ascending: false });
    if (error) return console.error(error);
    setPromos(await resolvePromotions(data as Promotion[]));
  }, []);

  useRealtimeTable<Promotion>({ table: "promotions", onChange: load, onSubscribed: load });

  const resetForm = () => {
    setFile(null);
    setMessage("");
    setFormKey((k) => k + 1);
  };

  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const supabase = getSupabase();
    try {
      let contentUrl: string | null = null;
      if (type !== "text") {
        if (!file) throw new Error("Elegí un archivo");
        const mime = baseMime(file.type);
        contentUrl = buildObjectPath(type, mime);
        const { error } = await supabase.storage.from(PROMO_BUCKET).upload(contentUrl, file, { contentType: mime });
        if (error) throw error;
      }
      const { error } = await supabase
        .from("promotions")
        .insert({ type, content_url: contentUrl, message: message.trim() || null, duration });
      if (error) throw error;
      resetForm();
    } catch (err) {
      alert(`No se pudo guardar: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      setBusy(false);
    }
  };

  const toggle = (p: Promotion) =>
    getSupabase().from("promotions").update({ is_active: !p.is_active }).eq("id", p.id).then(({ error }) => error && alert(error.message));

  const remove = async (p: Promotion) => {
    if (!confirm("¿Eliminar este anuncio?")) return;
    const supabase = getSupabase();
    const { error } = await supabase.from("promotions").delete().eq("id", p.id);
    if (error) return alert(error.message);
    if (p.content_url) await supabase.storage.from(PROMO_BUCKET).remove([p.content_url]);
  };

  return (
    <section className="space-y-6">
      <h2 className="text-xl font-semibold">Playlist de propaganda</h2>

      <form key={formKey} onSubmit={create} className="space-y-3 rounded-2xl bg-zinc-900 p-4 ring-1 ring-white/10">
        <div className="grid grid-cols-3 gap-1 rounded-xl bg-zinc-800 p-1 text-sm">
          {(["image", "video", "text"] as const).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => {
                setType(t);
                setDuration(DEFAULT_DURATION[t]);
              }}
              className={`rounded-lg py-2 ${type === t ? "bg-zinc-600" : "text-zinc-400"}`}
            >
              {t === "image" ? "Imagen" : t === "video" ? "Video" : "Texto"}
            </button>
          ))}
        </div>

        {type !== "text" && (
          <input
            type="file"
            required
            accept={type === "image" ? "image/jpeg,image/png,image/webp,image/gif" : "video/mp4,video/webm"}
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            className="w-full text-sm text-zinc-400 file:mr-3 file:rounded-lg file:border-0 file:bg-zinc-700 file:px-3 file:py-2 file:text-white"
          />
        )}

        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          required={type === "text"}
          rows={type === "text" ? 3 : 2}
          placeholder={type === "text" ? "Texto del aviso" : "Texto superpuesto (opcional)"}
          className="w-full resize-none rounded-xl bg-zinc-800 px-3 py-2 text-sm outline-none ring-1 ring-white/10 focus:ring-indigo-500"
        />

        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 text-sm text-zinc-400">
            Duración
            <input
              type="number"
              min={3}
              max={120}
              value={duration}
              onChange={(e) => setDuration(Number(e.target.value))}
              className="w-20 rounded-lg bg-zinc-800 px-2 py-1.5 text-white outline-none ring-1 ring-white/10"
            />
            s
          </label>
          <button disabled={busy} className="ml-auto rounded-xl bg-indigo-600 px-5 py-2 text-sm font-semibold disabled:opacity-50">
            {busy ? "Subiendo…" : "Agregar"}
          </button>
        </div>
      </form>

      <ul className="space-y-3">
        {promos.map((p) => (
          <li key={p.id} className="flex gap-3 rounded-2xl bg-zinc-900 p-2 ring-1 ring-white/5">
            <PostPreview type={p.type} url={p.url} message={p.type === "text" ? p.message : null} className="h-20 w-32 shrink-0 rounded-xl" />
            <div className="flex min-w-0 flex-1 flex-col justify-between py-1">
              <p className="truncate text-sm">{p.message ?? (p.type === "video" ? "Video" : "Imagen")}</p>
              <div className="flex items-center gap-3 text-xs text-zinc-500">
                <span>{p.duration} s</span>
                <button onClick={() => toggle(p)} className={p.is_active ? "text-emerald-400" : "text-zinc-500"}>
                  {p.is_active ? "● Activo" : "○ Pausado"}
                </button>
                <button onClick={() => remove(p)} className="ml-auto pr-2 hover:text-red-300">
                  Eliminar
                </button>
              </div>
            </div>
          </li>
        ))}
        {promos.length === 0 && <p className="text-sm text-zinc-500">Todavía no hay anuncios cargados.</p>}
      </ul>
    </section>
  );
}
