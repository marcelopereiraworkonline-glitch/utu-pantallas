"use client";

import { useCallback, useState } from "react";
import type { RealtimePostgresChangesPayload } from "@supabase/supabase-js";
import { getSupabase } from "@/lib/supabase/client";
import { communityUrl } from "@/lib/media";
import { COMMUNITY_BUCKET, type Post, type PostStatus } from "@/lib/types";
import { useRealtimeTable } from "@/hooks/useRealtimeTable";
import { PostPreview } from "@/components/admin/PostPreview";

const TYPE_LABEL = { video: "🎥 Video", image: "📷 Foto", text: "💬 Mensaje" } as const;
const VISIBLE: PostStatus[] = ["pending", "approved"];

function timeAgo(iso: string) {
  const s = Math.round((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return `hace ${s} s`;
  if (s < 3600) return `hace ${Math.floor(s / 60)} min`;
  return `hace ${Math.floor(s / 3600)} h`;
}

export function PendingInbox() {
  const [posts, setPosts] = useState<Map<string, Post>>(new Map());
  const [working, setWorking] = useState<Set<string>>(new Set());

  const load = useCallback(async () => {
    const { data, error } = await getSupabase()
      .from("posts")
      .select("*")
      .in("status", VISIBLE)
      .order("created_at", { ascending: true });
    if (error) return console.error(error);
    setPosts(new Map((data as Post[]).map((p) => [p.id, p])));
  }, []);

  const onChange = useCallback((payload: RealtimePostgresChangesPayload<Post>) => {
    setPosts((prev) => {
      const next = new Map(prev);
      if (payload.eventType === "DELETE") {
        next.delete(payload.old.id!);
      } else if (VISIBLE.includes(payload.new.status)) {
        next.set(payload.new.id, payload.new);
      } else {
        next.delete(payload.new.id);
      }
      return next;
    });
  }, []);

  useRealtimeTable<Post>({ table: "posts", onChange, onSubscribed: load });

  const setStatus = async (post: Post, status: PostStatus) => {
    setWorking((w) => new Set(w).add(post.id));
    const supabase = getSupabase();
    const { error } = await supabase.from("posts").update({ status }).eq("id", post.id);
    if (error) {
      alert(`No se pudo actualizar: ${error.message}`);
    } else if (status === "rejected" && post.content_url) {
      // El contenido denegado no se conserva
      await supabase.storage.from(COMMUNITY_BUCKET).remove([post.content_url]);
    }
    setWorking((w) => {
      const next = new Set(w);
      next.delete(post.id);
      return next;
    });
  };

  const all = [...posts.values()];
  const pending = all.filter((p) => p.status === "pending");
  const approved = all
    .filter((p) => p.status === "approved")
    .sort((a, b) => (a.approved_at ?? "").localeCompare(b.approved_at ?? ""));

  return (
    <section className="space-y-10">
      <div>
        <h2 className="mb-4 flex items-center gap-3 text-xl font-semibold">
          Bandeja de entrada
          <span className="rounded-full bg-indigo-500/20 px-3 py-0.5 text-sm text-indigo-300">{pending.length}</span>
        </h2>

        {pending.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-white/10 p-10 text-center text-zinc-500">
            No hay contenido pendiente. Los nuevos envíos aparecen acá al instante.
          </p>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {pending.map((post) => (
              <article key={post.id} className="overflow-hidden rounded-2xl bg-zinc-900 ring-1 ring-white/10">
                <PostPreview
                  type={post.type}
                  url={communityUrl(post.content_url)}
                  message={post.message}
                  className="aspect-video"
                />
                <div className="flex items-center justify-between px-4 py-3 text-sm text-zinc-400">
                  <span>{TYPE_LABEL[post.type]}</span>
                  <span>{timeAgo(post.created_at)}</span>
                </div>
                <div className="grid grid-cols-2 gap-2 px-4 pb-4">
                  <button
                    onClick={() => setStatus(post, "rejected")}
                    disabled={working.has(post.id)}
                    className="rounded-xl bg-red-500/15 py-2.5 font-semibold text-red-300 hover:bg-red-500/25 disabled:opacity-40"
                  >
                    Denegar
                  </button>
                  <button
                    onClick={() => setStatus(post, "approved")}
                    disabled={working.has(post.id)}
                    className="rounded-xl bg-emerald-500/15 py-2.5 font-semibold text-emerald-300 hover:bg-emerald-500/25 disabled:opacity-40"
                  >
                    Aprobar
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>

      <div>
        <h2 className="mb-4 flex items-center gap-3 text-xl font-semibold">
          En cola para la pantalla
          <span className="rounded-full bg-emerald-500/20 px-3 py-0.5 text-sm text-emerald-300">{approved.length}</span>
        </h2>
        {approved.length === 0 ? (
          <p className="text-sm text-zinc-500">Sin contenido aprobado en espera: la pantalla muestra propaganda.</p>
        ) : (
          <ol className="space-y-2">
            {approved.map((post, i) => (
              <li key={post.id} className="flex items-center gap-4 rounded-xl bg-zinc-900 p-2 pr-4 ring-1 ring-white/5">
                <span className="w-6 text-center text-zinc-500">{i + 1}</span>
                <PostPreview
                  type={post.type}
                  url={communityUrl(post.content_url)}
                  message={null}
                  className="h-14 w-24 shrink-0 rounded-lg"
                />
                <span className="flex-1 truncate text-sm text-zinc-300">{post.message ?? TYPE_LABEL[post.type]}</span>
                <button
                  onClick={() => setStatus(post, "rejected")}
                  disabled={working.has(post.id)}
                  className="text-sm text-zinc-500 hover:text-red-300"
                >
                  Quitar
                </button>
              </li>
            ))}
          </ol>
        )}
      </div>
    </section>
  );
}
