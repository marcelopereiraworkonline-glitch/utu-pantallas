"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { MAX_VIDEO_MS } from "@/lib/types";

const MIME_CANDIDATES = [
  "video/mp4;codecs=avc1", // Safari / iOS: se reproduce en cualquier navegador
  "video/mp4",
  "video/webm;codecs=vp9,opus",
  "video/webm;codecs=vp8,opus",
  "video/webm",
];

function pickMimeType(): string | undefined {
  return MIME_CANDIDATES.find((m) => MediaRecorder.isTypeSupported(m));
}

type Phase = "idle" | "recording" | "preview";

interface Props {
  onSubmit: (blob: Blob) => Promise<void>;
  busy: boolean;
}

export function VideoRecorder({ onSubmit, busy }: Props) {
  const liveRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const rafRef = useRef(0);
  const stopTimerRef = useRef<ReturnType<typeof setTimeout>>(undefined);

  const [facing, setFacing] = useState<"user" | "environment">("user");
  const [phase, setPhase] = useState<Phase>("idle");
  const [remaining, setRemaining] = useState(MAX_VIDEO_MS);
  const [clip, setClip] = useState<{ blob: Blob; url: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  // --- Cámara ---------------------------------------------------------------

  const stopStream = () => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  };

  useEffect(() => {
    if (phase === "preview") return;
    let cancelled = false;

    (async () => {
      const video = { facingMode: facing, width: { ideal: 1280 }, height: { ideal: 720 } };
      // iOS no permite abrir una segunda cámara mientras la anterior sigue activa
      stopStream();
      try {
        let stream: MediaStream;
        try {
          stream = await navigator.mediaDevices.getUserMedia({ video, audio: true });
        } catch {
          // Sin permiso de micrófono: se graba solo video
          stream = await navigator.mediaDevices.getUserMedia({ video });
        }
        if (cancelled) return stream.getTracks().forEach((t) => t.stop());
        streamRef.current = stream;
        if (liveRef.current) liveRef.current.srcObject = stream;
        setError(null);
      } catch {
        setError("No pudimos acceder a la cámara. Revisá los permisos del navegador.");
      }
    })();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- solo reabrir al cambiar de cámara o volver de la vista previa
  }, [facing, phase === "preview"]);

  useEffect(
    () => () => {
      cancelAnimationFrame(rafRef.current);
      clearTimeout(stopTimerRef.current);
      stopStream();
    },
    [],
  );

  useEffect(() => {
    if (!clip) return;
    return () => URL.revokeObjectURL(clip.url);
  }, [clip]);

  // --- Grabación ------------------------------------------------------------

  const stop = useCallback(() => {
    clearTimeout(stopTimerRef.current);
    cancelAnimationFrame(rafRef.current);
    if (recorderRef.current?.state === "recording") recorderRef.current.stop();
  }, []);

  const start = () => {
    const stream = streamRef.current;
    if (!stream) return;
    const mimeType = pickMimeType();
    const recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 2_500_000 });
    const chunks: Blob[] = [];

    recorder.ondataavailable = (e) => e.data.size && chunks.push(e.data);
    recorder.onstop = () => {
      const blob = new Blob(chunks, { type: recorder.mimeType || mimeType || "video/webm" });
      setClip({ blob, url: URL.createObjectURL(blob) });
      setPhase("preview");
      stopStream();
    };

    recorderRef.current = recorder;
    recorder.start(250);
    setPhase("recording");

    // Límite estricto: la grabación se corta sola a los 5 s
    const startedAt = performance.now();
    stopTimerRef.current = setTimeout(stop, MAX_VIDEO_MS);
    const tick = () => {
      const left = Math.max(0, MAX_VIDEO_MS - (performance.now() - startedAt));
      setRemaining(left);
      if (left > 0) rafRef.current = requestAnimationFrame(tick);
    };
    tick();
  };

  const retake = () => {
    setClip(null);
    setRemaining(MAX_VIDEO_MS);
    setPhase("idle");
  };

  // --- UI -------------------------------------------------------------------

  if (error) return <p className="rounded-2xl bg-red-500/10 p-6 text-center text-red-300">{error}</p>;

  const progress = remaining / MAX_VIDEO_MS;

  return (
    <div className="space-y-4">
      <div className="relative aspect-[9/16] max-h-[60dvh] w-full overflow-hidden rounded-3xl bg-zinc-900 ring-1 ring-white/10 sm:aspect-video">
        {phase === "preview" && clip ? (
          <video src={clip.url} autoPlay loop playsInline controls className="h-full w-full object-cover" />
        ) : (
          <video
            ref={liveRef}
            autoPlay
            muted
            playsInline
            className={`h-full w-full object-cover ${facing === "user" ? "-scale-x-100" : ""}`}
          />
        )}

        {phase === "recording" && (
          <>
            <div className="absolute left-4 top-4 flex items-center gap-2 rounded-full bg-black/60 px-3 py-1 text-sm font-medium">
              <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-red-500" />
              {(remaining / 1000).toFixed(1)} s
            </div>
            <div className="absolute inset-x-0 bottom-0 h-2 bg-white/10">
              <div
                className="h-full bg-red-500 transition-none"
                style={{ width: `${progress * 100}%` }}
              />
            </div>
          </>
        )}

        {phase === "idle" && (
          <button
            onClick={() => setFacing((f) => (f === "user" ? "environment" : "user"))}
            className="absolute right-4 top-4 rounded-full bg-black/60 px-3 py-2 text-sm"
            aria-label="Cambiar cámara"
          >
            🔄 Girar
          </button>
        )}
      </div>

      {phase === "idle" && (
        <button
          onClick={start}
          className="flex w-full items-center justify-center gap-3 rounded-2xl bg-red-600 py-4 text-lg font-semibold active:scale-[0.98]"
        >
          <span className="h-4 w-4 rounded-full bg-white" /> Grabar (máx. 5 s)
        </button>
      )}

      {phase === "recording" && (
        <button onClick={stop} className="w-full rounded-2xl bg-zinc-800 py-4 text-lg font-semibold">
          ■ Detener
        </button>
      )}

      {phase === "preview" && clip && (
        <div className="grid grid-cols-2 gap-3">
          <button onClick={retake} disabled={busy} className="rounded-2xl bg-zinc-800 py-4 font-semibold disabled:opacity-50">
            Repetir
          </button>
          <button
            onClick={() => onSubmit(clip.blob)}
            disabled={busy}
            className="rounded-2xl bg-indigo-600 py-4 font-semibold disabled:opacity-50"
          >
            {busy ? "Enviando…" : "Enviar"}
          </button>
        </div>
      )}
    </div>
  );
}
