"use client";

import { useState } from "react";
import { MAX_MESSAGE_LENGTH } from "@/lib/types";

interface Props {
  onSubmit: (message: string) => Promise<void>;
  busy: boolean;
}

export function TextComposer({ onSubmit, busy }: Props) {
  const [message, setMessage] = useState("");
  const left = MAX_MESSAGE_LENGTH - message.length;

  return (
    <div className="space-y-4">
      <div className="relative">
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          maxLength={MAX_MESSAGE_LENGTH}
          rows={6}
          placeholder="Escribí tu mensaje para la pantalla…"
          className="w-full resize-none rounded-3xl bg-zinc-900 p-5 text-lg outline-none ring-1 ring-white/10 focus:ring-indigo-500"
        />
        <span className={`absolute bottom-4 right-5 text-sm ${left < 20 ? "text-amber-400" : "text-zinc-500"}`}>{left}</span>
      </div>
      <button
        onClick={() => onSubmit(message)}
        disabled={!message.trim() || busy}
        className="w-full rounded-2xl bg-indigo-600 py-4 text-lg font-semibold disabled:opacity-40"
      >
        {busy ? "Enviando…" : "Enviar mensaje"}
      </button>
    </div>
  );
}
