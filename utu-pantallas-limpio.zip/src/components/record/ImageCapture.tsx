"use client";

import { useEffect, useState } from "react";
import { compressImage } from "@/lib/media";
import { MAX_MESSAGE_LENGTH } from "@/lib/types";

interface Props {
  onSubmit: (blob: Blob, caption: string) => Promise<void>;
  busy: boolean;
}

export function ImageCapture({ onSubmit, busy }: Props) {
  const [image, setImage] = useState<{ blob: Blob; url: string } | null>(null);
  const [caption, setCaption] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!image) return;
    return () => URL.revokeObjectURL(image.url);
  }, [image]);

  const onFile = async (file: File | undefined) => {
    if (!file) return;
    try {
      const blob = await compressImage(file);
      setImage({ blob, url: URL.createObjectURL(blob) });
      setError(null);
    } catch {
      setError("No pudimos leer esa imagen. Probá con otra.");
    }
  };

  return (
    <div className="space-y-4">
      <label className="relative flex aspect-square max-h-[55dvh] w-full cursor-pointer items-center justify-center overflow-hidden rounded-3xl bg-zinc-900 ring-1 ring-white/10">
        {image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={image.url} alt="Vista previa" className="h-full w-full object-contain" />
        ) : (
          <span className="text-center text-zinc-400">
            <span className="block text-5xl">📷</span>
            Tocá para sacar o elegir una foto
          </span>
        )}
        <input type="file" accept="image/*" className="sr-only" onChange={(e) => onFile(e.target.files?.[0])} />
      </label>

      {error && <p className="text-sm text-red-300">{error}</p>}

      <input
        value={caption}
        onChange={(e) => setCaption(e.target.value)}
        maxLength={MAX_MESSAGE_LENGTH}
        placeholder="Pie de foto (opcional)"
        className="w-full rounded-2xl bg-zinc-900 px-4 py-3 outline-none ring-1 ring-white/10 focus:ring-indigo-500"
      />

      <button
        onClick={() => image && onSubmit(image.blob, caption)}
        disabled={!image || busy}
        className="w-full rounded-2xl bg-indigo-600 py-4 text-lg font-semibold disabled:opacity-40"
      >
        {busy ? "Enviando…" : "Enviar foto"}
      </button>
    </div>
  );
}
