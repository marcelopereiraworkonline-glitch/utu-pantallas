"use client";

import { useState } from "react";
import { submitPost } from "@/lib/media";
import type { MediaType } from "@/lib/types";
import { VideoRecorder } from "@/components/record/VideoRecorder";
import { ImageCapture } from "@/components/record/ImageCapture";
import { TextComposer } from "@/components/record/TextComposer";

const TABS: { type: MediaType; label: string; hint: string }[] = [
  { type: "video", label: "🎥 Video", hint: "5 segundos" },
  { type: "image", label: "📷 Foto", hint: "5 segundos en pantalla" },
  { type: "text", label: "💬 Mensaje", hint: "10 segundos en pantalla" },
];

export default function RecordPage() {
  const [tab, setTab] = useState<MediaType>("video");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const send = async (input: Parameters<typeof submitPost>[0]) => {
    setBusy(true);
    setError(null);
    try {
      await submitPost(input);
      setSent(true);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Algo salió mal. Probá de nuevo.");
    } finally {
      setBusy(false);
    }
  };

  if (sent) {
    return (
      <main className="mx-auto flex min-h-dvh max-w-md flex-col items-center justify-center gap-6 p-6 text-center">
        <div className="text-7xl">✅</div>
        <h1 className="text-3xl font-bold">¡Recibido!</h1>
        <p className="text-zinc-400">
          Tu contenido quedó pendiente de revisión. Si un moderador lo aprueba, va a aparecer en las pantallas de la UTU.
        </p>
        <button onClick={() => setSent(false)} className="rounded-2xl bg-indigo-600 px-8 py-4 font-semibold">
          Enviar otro
        </button>
      </main>
    );
  }

  const current = TABS.find((t) => t.type === tab)!;

  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col gap-5 p-4 pb-10">
      <header className="pt-4 text-center">
        <h1 className="text-2xl font-bold">Salí en la pantalla 📺</h1>
        <p className="text-sm text-zinc-400">Mandá tu contenido a las pantallas de la UTU</p>
      </header>

      <nav className="grid grid-cols-3 gap-1 rounded-2xl bg-zinc-900 p-1">
        {TABS.map((t) => (
          <button
            key={t.type}
            onClick={() => setTab(t.type)}
            disabled={busy}
            className={`rounded-xl py-3 text-sm font-medium transition ${
              tab === t.type ? "bg-zinc-700 text-white" : "text-zinc-400"
            }`}
          >
            {t.label}
          </button>
        ))}
      </nav>
      <p className="-mt-2 text-center text-xs text-zinc-500">{current.hint}</p>

      {tab === "video" && <VideoRecorder busy={busy} onSubmit={(blob) => send({ type: "video", blob })} />}
      {tab === "image" && (
        <ImageCapture busy={busy} onSubmit={(blob, message) => send({ type: "image", blob, message })} />
      )}
      {tab === "text" && <TextComposer busy={busy} onSubmit={(message) => send({ type: "text", message })} />}

      {error && <p className="rounded-xl bg-red-500/10 p-3 text-center text-sm text-red-300">{error}</p>}

      <p className="mt-auto text-center text-xs text-zinc-600">
        Todo el contenido es revisado antes de publicarse. Respetá las normas de convivencia.
      </p>
    </main>
  );
}
