"use client";

import { useModerator } from "@/hooks/useModerator";
import { SignOutButton } from "@/components/SignOutButton";

const OPTIONS = [
  {
    href: "/admin",
    icon: "🛡️",
    title: "Panel de Moderación",
    description: "Aprobá o denegá el contenido de la comunidad y gestioná la playlist de propaganda.",
  },
  {
    href: "/display",
    icon: "📺",
    title: "Pantalla de Transmisión",
    description: "Abrila en la TV o proyector, en pantalla completa, con el QR para participar.",
  },
];

export default function DashboardPage() {
  const { email, isModerator } = useModerator();

  return (
    <main className="mx-auto flex min-h-dvh max-w-4xl flex-col gap-10 p-6 sm:p-10">
      <header className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Pantallas UTU</h1>
          <p className="text-zinc-400">{email ?? " "}</p>
        </div>
        <SignOutButton />
      </header>

      {isModerator === false && (
        <p className="rounded-2xl bg-amber-500/10 p-4 text-amber-300 ring-1 ring-amber-500/30">
          Esta cuenta no está registrada como moderadora. Pedí a un administrador que la agregue a la tabla
          <code className="mx-1 rounded bg-black/30 px-1">moderators</code>.
        </p>
      )}

      <div className="grid gap-6 sm:grid-cols-2">
        {OPTIONS.map((o) => (
          <a
            key={o.href}
            href={o.href}
            target="_blank"
            rel="noopener"
            className="group rounded-3xl bg-zinc-900 p-8 ring-1 ring-white/10 transition hover:-translate-y-1 hover:ring-indigo-500/60"
          >
            <div className="mb-6 text-5xl">{o.icon}</div>
            <h2 className="mb-2 text-xl font-semibold">{o.title}</h2>
            <p className="mb-6 text-zinc-400">{o.description}</p>
            <span className="text-sm font-medium text-indigo-400 group-hover:text-indigo-300">Abrir en pestaña nueva ↗</span>
          </a>
        ))}
      </div>
    </main>
  );
}
