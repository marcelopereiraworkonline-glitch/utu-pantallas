"use client";

import { useEffect, useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { usePlaylist } from "@/hooks/usePlaylist";
import { MediaStage } from "@/components/display/MediaStage";

export default function DisplayPage() {
  // El navegador solo permite video con sonido después de una interacción del usuario
  const [started, setStarted] = useState(false);
  const [recordUrl, setRecordUrl] = useState("");
  const { current, queueSize, promoCount, skip } = usePlaylist(started);

  useEffect(() => {
    const base = process.env.NEXT_PUBLIC_SITE_URL || window.location.origin;
    // eslint-disable-next-line react-hooks/set-state-in-effect -- depende de window, solo existe en el cliente
    setRecordUrl(new URL("/record", base).toString());
  }, []);

  // Mantiene la pantalla encendida mientras se transmite
  useEffect(() => {
    if (!started || !("wakeLock" in navigator)) return;
    let lock: WakeLockSentinel | undefined;
    const acquire = () => navigator.wakeLock.request("screen").then((l) => (lock = l)).catch(() => {});
    acquire();
    const onVisible = () => document.visibilityState === "visible" && acquire();
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      document.removeEventListener("visibilitychange", onVisible);
      lock?.release();
    };
  }, [started]);

  const start = async () => {
    setStarted(true);
    await document.documentElement.requestFullscreen?.().catch(() => {});
  };

  return (
    <main className="relative h-dvh w-screen cursor-none overflow-hidden bg-black text-white">
      {current ? (
        <MediaStage key={current.playId} slot={current} onError={skip} />
      ) : (
        <IdleScreen />
      )}

      {current && (
        <>
          <div className="absolute left-8 top-8 rounded-full bg-black/50 px-5 py-2 text-xl font-medium backdrop-blur">
            {current.source === "community" ? "💬 Comunidad" : "📢 UTU Informa"}
          </div>
          <div className="absolute inset-x-0 bottom-0 h-1.5 bg-white/10">
            <div
              key={current.playId}
              className="h-full origin-left bg-indigo-400"
              style={{ animation: `progress ${current.duration}s linear forwards` }}
            />
          </div>
        </>
      )}

      {recordUrl && (
        <aside className="absolute bottom-8 right-8 flex items-center gap-5 rounded-3xl bg-black/70 p-5 shadow-2xl ring-1 ring-white/10 backdrop-blur-md">
          <div className="text-right">
            <p className="text-2xl font-bold">¡Participá!</p>
            <p className="text-lg text-white/70">Escaneá y enviá tu</p>
            <p className="text-lg text-white/70">video, foto o mensaje</p>
          </div>
          <div className="rounded-2xl bg-white p-3">
            <QRCodeSVG value={recordUrl} size={150} level="M" />
          </div>
        </aside>
      )}

      <div className="absolute right-8 top-8 text-sm text-white/30">
        En cola: {queueSize} · Anuncios: {promoCount}
      </div>

      {!started && (
        <button
          onClick={start}
          className="absolute inset-0 z-10 flex cursor-pointer flex-col items-center justify-center gap-4 bg-black/85 backdrop-blur"
        >
          <span className="rounded-full bg-indigo-500 px-10 py-5 text-3xl font-semibold shadow-lg shadow-indigo-500/30">
            ▶ Iniciar transmisión
          </span>
          <span className="text-white/50">Pantalla completa con sonido habilitado</span>
        </button>
      )}
    </main>
  );
}

function IdleScreen() {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-6 bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-950">
      <h1 className="text-8xl font-black tracking-tight">UTU</h1>
      <p className="text-3xl text-white/60">Esta pantalla es tuya. Escaneá el código y mandá tu contenido.</p>
    </div>
  );
}
