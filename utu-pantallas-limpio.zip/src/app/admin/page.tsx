"use client";

import { PendingInbox } from "@/components/admin/PendingInbox";
import { PromotionsManager } from "@/components/admin/PromotionsManager";
import { SignOutButton } from "@/components/SignOutButton";
import { useModerator } from "@/hooks/useModerator";

export default function AdminPage() {
  const { email, isModerator } = useModerator();

  return (
    <main className="mx-auto max-w-[1600px] p-4 sm:p-8">
      <header className="mb-8 flex items-center justify-between gap-4">
        <div>
          <h1 className="flex items-center gap-3 text-2xl font-bold">
            Panel de Moderación
            <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-xs font-medium text-emerald-400">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" /> En vivo
            </span>
          </h1>
          <p className="text-sm text-zinc-500">{email ?? " "}</p>
        </div>
        <div className="flex items-center gap-3">
          <a href="/display" target="_blank" rel="noopener" className="rounded-xl px-4 py-2 text-sm ring-1 ring-white/10 hover:bg-white/5">
            Abrir pantalla ↗
          </a>
          <SignOutButton />
        </div>
      </header>

      {isModerator === false ? (
        <p className="rounded-2xl bg-amber-500/10 p-4 text-amber-300">Esta cuenta no tiene permisos de moderación.</p>
      ) : (
        <div className="grid gap-10 lg:grid-cols-[1fr_420px]">
          <PendingInbox />
          <PromotionsManager />
        </div>
      )}
    </main>
  );
}
