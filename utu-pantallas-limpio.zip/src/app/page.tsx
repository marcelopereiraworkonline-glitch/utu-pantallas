// El QR y la raíz del sitio llevan directo a la vista de captura
export { default } from "./record/page";
