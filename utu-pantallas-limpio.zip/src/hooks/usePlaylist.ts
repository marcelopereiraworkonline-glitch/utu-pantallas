"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { RealtimePostgresChangesPayload } from "@supabase/supabase-js";
import { getSupabase } from "@/lib/supabase/client";
import { communityUrl, resolvePromotions, type ResolvedPromotion } from "@/lib/media";
import type { MediaType, Post, Promotion } from "@/lib/types";
import { useRealtimeTable } from "@/hooks/useRealtimeTable";

export interface Slot {
  /** Identificador único de esta reproducción (cambia aunque se repita el mismo anuncio) */
  playId: number;
  source: "community" | "promo";
  id: string;
  type: MediaType;
  url: string | null;
  message: string | null;
  duration: number;
}

const POSTS_RESYNC_MS = 60_000;
const PROMOS_REFRESH_MS = 30 * 60_000; // las URLs firmadas duran 2 h

const byApproval = (a: Post, b: Post) =>
  (a.approved_at ?? a.created_at).localeCompare(b.approved_at ?? b.created_at);

/**
 * Reproductor con dos colas:
 *  1. Comunidad (prioridad): posts aprobados, FIFO, se reproducen UNA vez y se marcan `played`.
 *  2. Propaganda (fallback): anuncios activos en orden aleatorio, en bucle.
 *
 * Regla de NO interrupción: los cambios en las colas nunca cortan lo que está en pantalla.
 * La siguiente pieza se elige únicamente cuando termina la actual (o si la pantalla está vacía).
 */
export function usePlaylist(enabled: boolean) {
  const [current, setCurrent] = useState<Slot | null>(null);
  const [queueSize, setQueueSize] = useState(0);
  const [promoCount, setPromoCount] = useState(0);

  const queueRef = useRef<Post[]>([]);
  const promosRef = useRef<ResolvedPromotion[]>([]);
  const currentRef = useRef<Slot | null>(null);
  const enabledRef = useRef(enabled);
  const playIdRef = useRef(0);
  const lastPromoIdRef = useRef<string | null>(null);
  // Posts ya tomados por este reproductor; evita repetirlos si un resync llega antes que el UPDATE
  const consumedRef = useRef(new Set<string>());

  const setQueue = useCallback((posts: Post[]) => {
    queueRef.current = posts.sort(byApproval);
    setQueueSize(posts.length);
  }, []);

  const pickNext = useCallback((): Slot | null => {
    const id = ++playIdRef.current;

    // 1) Prioridad absoluta: cola de la comunidad
    const [post, ...rest] = queueRef.current;
    if (post) {
      setQueue(rest);
      consumedRef.current.add(post.id);
      return {
        playId: id,
        source: "community",
        id: post.id,
        type: post.type,
        url: communityUrl(post.content_url),
        message: post.message,
        duration: post.duration,
      };
    }

    // 2) Fallback: propaganda aleatoria, evitando repetir el último si hay más de uno
    const promos = promosRef.current.filter((p) => p.type === "text" || p.url);
    if (!promos.length) return null;
    const pool = promos.length > 1 ? promos.filter((p) => p.id !== lastPromoIdRef.current) : promos;
    const promo = pool[Math.floor(Math.random() * pool.length)];
    lastPromoIdRef.current = promo.id;
    return {
      playId: id,
      source: "promo",
      id: promo.id,
      type: promo.type,
      url: promo.url,
      message: promo.message,
      duration: promo.duration,
    };
  }, [setQueue]);

  /** Termina la pieza actual y pasa a la siguiente */
  const advance = useCallback(() => {
    const finished = currentRef.current;
    if (finished?.source === "community") {
      // Efímero: se marca como reproducido apenas termina
      getSupabase()
        .from("posts")
        .update({ status: "played" })
        .eq("id", finished.id)
        .then(({ error }) => error && console.error("No se pudo marcar como reproducido", error));
    }
    const next = enabledRef.current ? pickNext() : null;
    currentRef.current = next;
    setCurrent(next);
  }, [pickNext]);

  /** Si la pantalla está en reposo y llegó contenido, arranca ya (no hay nada que interrumpir) */
  const kickIfIdle = useCallback(() => {
    if (enabledRef.current && !currentRef.current) advance();
  }, [advance]);

  // --- Carga de datos -------------------------------------------------------

  const loadPosts = useCallback(async () => {
    const { data, error } = await getSupabase()
      .from("posts")
      .select("*")
      .eq("status", "approved")
      .order("approved_at", { ascending: true });
    if (error) return console.error(error);
    setQueue((data as Post[]).filter((p) => !consumedRef.current.has(p.id)));
    kickIfIdle();
  }, [setQueue, kickIfIdle]);

  const loadPromos = useCallback(async () => {
    const { data, error } = await getSupabase()
      .from("promotions")
      .select("*")
      .eq("is_active", true)
      .order("created_at");
    if (error) return console.error(error);
    promosRef.current = await resolvePromotions(data as Promotion[]);
    setPromoCount(promosRef.current.length);
    kickIfIdle();
  }, [kickIfIdle]);

  const onPostChange = useCallback(
    (payload: RealtimePostgresChangesPayload<Post>) => {
      if (payload.eventType === "DELETE") {
        setQueue(queueRef.current.filter((p) => p.id !== payload.old.id));
        return;
      }
      const post = payload.new;
      const others = queueRef.current.filter((p) => p.id !== post.id);
      if (post.status === "approved" && !consumedRef.current.has(post.id)) {
        setQueue([...others, post]);
        kickIfIdle();
      } else {
        // Rechazado/reproducido (p. ej. por otra pantalla) → fuera de la cola
        setQueue(others);
      }
    },
    [setQueue, kickIfIdle],
  );

  useRealtimeTable<Post>({ table: "posts", onChange: onPostChange, onSubscribed: loadPosts });
  useRealtimeTable<Promotion>({ table: "promotions", onChange: loadPromos, onSubscribed: loadPromos });

  // Resincronización periódica como red de seguridad ante cortes de red
  useEffect(() => {
    const posts = setInterval(loadPosts, POSTS_RESYNC_MS);
    const promos = setInterval(loadPromos, PROMOS_REFRESH_MS);
    return () => {
      clearInterval(posts);
      clearInterval(promos);
    };
  }, [loadPosts, loadPromos]);

  // --- Encendido / temporizador -------------------------------------------

  useEffect(() => {
    enabledRef.current = enabled;
    if (enabled) kickIfIdle();
  }, [enabled, kickIfIdle]);

  // El temporizador es la fuente de verdad de la duración (5 s / 10 s), también para videos
  useEffect(() => {
    if (!current) return;
    const t = setTimeout(advance, current.duration * 1000);
    return () => clearTimeout(t);
  }, [current, advance]);

  return { current, queueSize, promoCount, skip: advance };
}
