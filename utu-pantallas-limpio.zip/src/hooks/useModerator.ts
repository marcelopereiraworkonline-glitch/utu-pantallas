"use client";

import { useEffect, useState } from "react";
import { getSupabase } from "@/lib/supabase/client";

/** null = verificando; false = la cuenta existe pero no está en la tabla `moderators` */
export function useModerator() {
  const [state, setState] = useState<{ email: string | null; isModerator: boolean | null }>({
    email: null,
    isModerator: null,
  });

  useEffect(() => {
    const supabase = getSupabase();
    Promise.all([supabase.auth.getUser(), supabase.rpc("is_moderator")]).then(([user, mod]) =>
      setState({ email: user.data.user?.email ?? null, isModerator: mod.data === true }),
    );
  }, []);

  return state;
}
