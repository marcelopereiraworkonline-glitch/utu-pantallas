"use client";

import { useEffect, useRef } from "react";
import type { RealtimePostgresChangesPayload } from "@supabase/supabase-js";
import { getSupabase } from "@/lib/supabase/client";

type Row = Record<string, unknown>;

interface Options<T extends Row> {
  table: string;
  /** Se llama con cada INSERT / UPDATE / DELETE */
  onChange: (payload: RealtimePostgresChangesPayload<T>) => void;
  /** Se llama al (re)conectar: sirve para resincronizar el estado completo y no perder eventos */
  onSubscribed?: () => void;
}

/**
 * Suscripción a `postgres_changes` de una tabla. Los eventos respetan RLS,
 * así que solo llegan a usuarios con permiso de lectura (moderadores).
 */
export function useRealtimeTable<T extends Row>({ table, onChange, onSubscribed }: Options<T>) {
  // Refs para no re-suscribirse cada vez que cambian los callbacks
  const onChangeRef = useRef(onChange);
  const onSubscribedRef = useRef(onSubscribed);
  useEffect(() => {
    onChangeRef.current = onChange;
    onSubscribedRef.current = onSubscribed;
  });

  useEffect(() => {
    const supabase = getSupabase();
    const channel = supabase
      .channel(`rt:${table}:${crypto.randomUUID()}`)
      .on<T>("postgres_changes", { event: "*", schema: "public", table }, (payload) =>
        onChangeRef.current(payload),
      )
      .subscribe((status) => {
        if (status === "SUBSCRIBED") onSubscribedRef.current?.();
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [table]);
}
