import { getSupabase } from "@/lib/supabase/client";
import { COMMUNITY_BUCKET, PROMO_BUCKET, type MediaType, type Promotion } from "@/lib/types";

const EXT_BY_MIME: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
  "video/webm": "webm",
  "video/mp4": "mp4",
  "video/quicktime": "mov",
};

/** "video/webm;codecs=vp9" → "video/webm" (Storage valida el MIME sin parámetros) */
export function baseMime(mime: string): string {
  return mime.split(";")[0].trim().toLowerCase();
}

export function buildObjectPath(kind: Exclude<MediaType, "text">, mime: string): string {
  const ext = EXT_BY_MIME[baseMime(mime)];
  if (!ext) throw new Error(`Formato no soportado: ${mime}`);
  return `${kind}/${crypto.randomUUID()}.${ext}`;
}

export function communityUrl(path: string | null): string | null {
  if (!path) return null;
  return getSupabase().storage.from(COMMUNITY_BUCKET).getPublicUrl(path).data.publicUrl;
}

export type ResolvedPromotion = Promotion & { url: string | null };

/** Resuelve las rutas privadas de promo-media a URLs firmadas (un solo request) */
export async function resolvePromotions(
  promos: Promotion[],
  expiresIn = 60 * 60 * 2,
): Promise<ResolvedPromotion[]> {
  const paths = promos.map((p) => p.content_url).filter((p): p is string => Boolean(p));
  const urls = new Map<string, string>();
  if (paths.length) {
    const { data } = await getSupabase().storage.from(PROMO_BUCKET).createSignedUrls(paths, expiresIn);
    data?.forEach((d) => d.path && d.signedUrl && urls.set(d.path, d.signedUrl));
  }
  return promos.map((p) => ({ ...p, url: p.content_url ? (urls.get(p.content_url) ?? null) : null }));
}

/** Reduce fotos de celular (a menudo >5 MB) a JPEG de hasta `maxSide` px */
export async function compressImage(file: File, maxSide = 1920, quality = 0.85): Promise<Blob> {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  canvas.getContext("2d")!.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  return new Promise((resolve, reject) =>
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("No se pudo procesar la imagen"))), "image/jpeg", quality),
  );
}

/** Envía un post de la comunidad: sube el archivo (si hay) y crea la fila en estado `pending` */
export async function submitPost(input: { type: MediaType; blob?: Blob; message?: string }) {
  const supabase = getSupabase();
  let contentUrl: string | null = null;

  if (input.type !== "text") {
    if (!input.blob) throw new Error("Falta el archivo");
    const mime = baseMime(input.blob.type);
    contentUrl = buildObjectPath(input.type, mime);
    const { error } = await supabase.storage
      .from(COMMUNITY_BUCKET)
      .upload(contentUrl, input.blob, { contentType: mime, upsert: false });
    if (error) throw new Error(`Error al subir el archivo: ${error.message}`);
  }

  const message = input.message?.trim() || null;
  // Sin .select(): el público no tiene permiso de lectura sobre posts
  const { error } = await supabase.from("posts").insert({ type: input.type, content_url: contentUrl, message });
  if (error) throw new Error(`Error al enviar: ${error.message}`);
}
