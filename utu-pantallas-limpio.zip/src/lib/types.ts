export type MediaType = "video" | "image" | "text";
export type PostStatus = "pending" | "approved" | "rejected" | "played";

export type Post = {
  id: string;
  type: MediaType;
  content_url: string | null;
  message: string | null;
  duration: number;
  status: PostStatus;
  created_at: string;
  approved_at: string | null;
};

export type Promotion = {
  id: string;
  type: MediaType;
  content_url: string | null;
  message: string | null;
  duration: number;
  is_active: boolean;
  created_at: string;
};

export const COMMUNITY_BUCKET = "community-media";
export const PROMO_BUCKET = "promo-media";

export const MAX_MESSAGE_LENGTH = 280;
export const MAX_VIDEO_MS = 5000;
