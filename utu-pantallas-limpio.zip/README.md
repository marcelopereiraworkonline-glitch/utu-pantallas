# Pantallas UTU

Contenido de la comunidad, moderado y en tiempo real, en las pantallas de la UTU.
Next.js 16 (App Router) + Tailwind CSS 4 + Supabase (Auth, Postgres, Storage, Realtime).

| Ruta         | Acceso       | Para qué                                                              |
| ------------ | ------------ | --------------------------------------------------------------------- |
| `/`, `/record` | Público    | Enviar un video (5 s), una foto o un mensaje. Queda en `pending`.     |
| `/login`     | Público      | Ingreso de moderadores                                                |
| `/dashboard` | Moderadores  | Elegir abrir el Panel o la Pantalla en una pestaña nueva              |
| `/admin`     | Moderadores  | Aprobar o denegar en tiempo real y gestionar la playlist de propaganda |
| `/display`   | Moderadores  | Reproductor a pantalla completa con QR hacia `/record`                |

## Puesta en marcha

1. **Crear el proyecto en Supabase** y ejecutar `supabase/migrations/0001_init.sql` en el SQL Editor.
   Eso crea los enums, las tablas, los triggers, las políticas RLS, los buckets y la publicación Realtime.
2. **Desactivar el registro público:** Authentication → Sign In / Providers → desactivar *Allow new users to sign up*.
3. **Crear las cuentas de moderador** (Authentication → Users → *Add user*) y darles permiso:
   ```sql
   insert into public.moderators (user_id)
   select id from auth.users where email in ('mod1@utu.edu.uy', 'mod2@utu.edu.uy', 'mod3@utu.edu.uy');
   ```
4. **Variables de entorno:** copiar `.env.example` a `.env.local` y completarlo.
5. `npm install && npm run dev`

### Despliegue en Vercel

Importar el repo y cargar las mismas variables de entorno (`NEXT_PUBLIC_SUPABASE_URL`,
`NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`, `NEXT_PUBLIC_SITE_URL`). En Supabase → Authentication → URL
Configuration, poner el dominio de Vercel como *Site URL*.

> La cámara (`getUserMedia`) solo funciona sobre HTTPS o `localhost`. Para probar desde el celular en
> desarrollo, usá el deploy de Vercel o un túnel HTTPS.

## Lógica del reproductor (`src/hooks/usePlaylist.ts`)

- **Cola de comunidad (prioridad):** posts `approved` en orden FIFO de aprobación (`approved_at`).
  Cada uno se muestra una sola vez y al terminar pasa a `played`.
- **Cola de propaganda (fallback):** anuncios `is_active`, en orden aleatorio sin repetir el anterior.
- **Sin interrupciones:** un post nuevo solo entra a la cola. La próxima pieza se elige cuando termina
  la actual, así que el anuncio en curso siempre se completa. Si la pantalla está en reposo, el post
  arranca de inmediato.
- La duración la controla un temporizador (5 s para video e imagen, 10 s para texto; la de cada anuncio
  es configurable). Los cambios llegan por `postgres_changes`, con resincronización al reconectar y cada
  60 s.
- `/display` pide un clic en «Iniciar transmisión», porque el navegador solo permite reproducir audio
  después de una interacción. También activa la pantalla completa y el Wake Lock.

## Seguridad

- El público solo puede **insertar** en `posts` (siempre como `pending`) y subir archivos a
  `community-media/{image|video}/`. No puede leer la tabla.
- Un trigger fija `duration`, `status` y las fechas en el servidor. `content_url` debe ser una ruta del
  bucket con formato `{tipo}/{uuid}.{ext}`, nunca una URL externa.
- `promo-media` es privado: la pantalla y el panel usan URLs firmadas por 2 h, que se renuevan cada 30 min.
- El contenido denegado se borra de Storage.

**Pendiente para producción:** el envío anónimo no tiene límite de frecuencia. Si aparece spam, agregar
Cloudflare Turnstile o un límite por IP (por ejemplo, un Route Handler o una Edge Function que haga el
insert).
